<?php

error_reporting(-1);

$dsn = "mysql:host=localhost;dbname=test;charset=utf8";
$opt = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];
$pdo = new PDO($dsn, 'root', '', $opt);

function debug($data){
    echo '<pre>' . print_r($data, 1) . '</pre>';
}

$stmt = $pdo->prepare("SELECT * FROM categories");
$stmt->execute();

while ($row = $stmt->fetch()) {
    $data[$row['id']] = $row;
}

//debug($data);
$tree = getTree($data);
debug($tree);

function getTree($data){
//    $i = $i ?? 0;
    $tree = [];

    foreach ($data as $id => &$node) {
        if (!$node['parent_id']){
            $tree[$id] =& $node;
        } else {
            $data[$node['parent_id']]['children'][$id] =& $node;
        }

        /*$i++;
        echo "============($i) DATA============";
        debug($data);
        echo "============($i) TREE============";
        debug($tree);
        echo '<br><br><br><br><br>';*/
    }

    return $tree;
}
